package lk.ijse.dep.web.pos.entity;

public interface CustomEntity {

    // code
    String getCode();

    // description
    String getDescription();

}
