package lk.ijse.dep.web.pos.business;

public interface SuperBO {
}
