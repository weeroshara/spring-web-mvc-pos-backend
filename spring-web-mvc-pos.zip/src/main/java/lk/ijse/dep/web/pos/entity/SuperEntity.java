package lk.ijse.dep.web.pos.entity;

import java.io.Serializable;

public interface SuperEntity extends Serializable {
}
